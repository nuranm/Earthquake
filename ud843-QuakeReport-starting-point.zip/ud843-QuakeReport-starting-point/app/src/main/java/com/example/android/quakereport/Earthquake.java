package com.example.android.quakereport;

import java.util.Date;

public class Earthquake {
    private String mdenger;
    private String mCity;
    private String mDate;

    public Earthquake(String denger,String city,String date){
        mdenger=denger;
        mCity=city;
        mDate=date;
    }

    public String getDenger() {
        return mdenger;
    }

    public String getCity() {
        return mCity;
    }

    public String getDate() {
        return mDate;
    }
}
